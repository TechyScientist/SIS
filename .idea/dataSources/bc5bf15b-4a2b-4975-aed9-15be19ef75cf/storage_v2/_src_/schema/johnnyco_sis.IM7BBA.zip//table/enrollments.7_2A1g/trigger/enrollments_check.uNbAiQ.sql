create definer = johnnyco@localhost trigger enrollments_check
    before insert
    on enrollments
    for each row
BEGIN
    DECLARE isStudent INT;
    DECLARE canEnroll INT;
    
    -- Initialize variables
    SET isStudent = (SELECT COUNT(*) FROM users WHERE studentNumber = NEW.student);
    
    IF isStudent = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid enrollment: User is not a student';
    END IF;
    
    SET canEnroll = (SELECT COUNT(*) FROM users WHERE studentNumber = NEW.student AND studentStatus <> 'Suspended');
    
    IF canEnroll = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid enrollment: Student is suspended';
    END IF;
    
END;

