create definer = johnnyco@localhost trigger courses_insert_check
    before insert
    on courses
    for each row
BEGIN
    DECLARE isInstructor INT;
    
    -- Initialize variable
    SELECT COUNT(*) INTO isInstructor FROM users WHERE (userType = 'Administrator' OR userType = 'Instructor') AND username = NEW.instructor;
    
    IF isInstructor = 0 THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid instructor assignment: User is not an instructor';
    END IF;
    
END;

